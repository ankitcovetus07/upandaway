<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">
<title>UAA-ABOUT</title>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="css/jumbotron-narrow.css" rel="stylesheet">

<!-- Just for debugging purposes. Don't actually copy this line! -->
<!--[if lt IE 9]><script src="../../docs-assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

<link href="css/my_style.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="font/css/font-awesome.min.css" rel="stylesheet">
<link href="font/css/font-awesome.css" rel="stylesheet">
<!--search box css-->
<link href="search/search_st.css" rel="stylesheet" type="text/css" />
<link href="search/calender.css" rel="stylesheet" type="text/css"  />
<link href="search/dropdown.css" rel="stylesheet" type="text/css"   />
<link href="search/menu.css" rel="stylesheet" type="text/css"  />
<link href="search/style.css" rel="stylesheet" type="text/css" />
<!--search box css-->
</head>

<body>

  <?php include('header.php'); ?>

<div class="clearfix"></div>

<!--Content start-->
<div class="container">
  <div class="col-lg-12">
  		<div class="col-lg-12">
        <h1>ABOUT US</h1>
        <p>Established in 1984 and with 5 offices nationwide, we are one of the oldest Airline Ticket Consolidators in North America.</p>
        <p>Our mission is to provide the best service and travel experience to our customers while engaging the services of only the finest airlines at the best possible fares. To this end we work with the most reputable US and international airlines for travel in both, economy and business class to worldwide destinations.</p>
        <p>We offer deeply discounted airfares, even at the last minute when these fares are not available from the airlines. We offer these on the major carriers and the discounts can be as much as 50% - 70% as compared to the airlines' published fares.</p>
        <p>Our success in this area has resulted in several travel industry awards and recognition by USA Today and the renowned consumer publication, CONSUMER REPORTS .</p>
        </div>
        <div class="clearfix">&nbsp;</div>
        
  </div>
  <hr>
  
</div>
<!--Content End-->

<div class="clearfix"></div>
<?php include('footer.php');?>
<!-- Bootstrap core JavaScript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="css/bootstrap.min.js"></script>
</body>
</html>
