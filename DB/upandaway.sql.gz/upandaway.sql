-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `flightcategory`;
CREATE TABLE `flightcategory` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `flightcategory` (`id`, `category_name`) VALUES
(2,	'Economy'),
(3,	'Premium'),
(4,	'Business');

DROP TABLE IF EXISTS `flightdetail`;
CREATE TABLE `flightdetail` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cate_id` int(10) NOT NULL,
  `cate_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `flightfrom` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `flightto` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `flightdetail` (`id`, `cate_id`, `cate_name`, `flightfrom`, `flightto`, `price`) VALUES
(58,	2,	'Economy',	'Chicago',	'New Delhi',	612),
(54,	2,	'Economy',	'Honolulu',	'Tokyo',	921),
(55,	2,	'Economy',	'Washington',	'Frankfurt',	291),
(57,	2,	'Economy',	'Atlanta',	'Zurich',	434),
(56,	2,	'Economy',	'Miami',	'Sao Paulo',	773),
(52,	2,	'Economy',	'New York',	'Rome',	328),
(53,	2,	'Economy',	'Los Angeles',	'Sydney',	1531),
(59,	2,	'Economy',	'Dallas',	'Dubai',	893),
(60,	2,	'Economy',	'Salt Lake',	'Paris',	506),
(61,	4,	'Business',	'New York',	'Copenhagen',	1501),
(62,	4,	'Business',	'New York',	'New Delhi',	2800),
(63,	4,	'Business',	'Boston',	'Riyadh',	2904),
(64,	4,	'Business',	'Washington',	'Sydney',	7500),
(65,	4,	'Business',	'San Francisco',	'Beijing',	3004),
(66,	4,	'Business',	'Tampa',	'London',	2500),
(67,	4,	'Business',	'Norfolk',	'Madrid',	1991),
(68,	4,	'Business',	'Detroit',	'Manila',	3652),
(69,	4,	'Business',	'Miami',	'Rio de Janeiro',	3805),
(70,	3,	'Premium',	'New York',	'Paris',	1201),
(71,	3,	'Premium',	'Houston',	'Doha',	1651),
(72,	3,	'Premium',	'Denver',	'Mumbai',	1809),
(73,	3,	'Premium',	'Seattle',	'Tokyo',	2001),
(74,	3,	'Premium',	'San Diego',	'Perth',	2490),
(75,	3,	'Premium',	'Orlando',	'Buenos Aires',	1504),
(76,	3,	'Premium',	'Washington ',	'Kuwait ',	1705),
(77,	3,	'Premium',	'Indianapolis',	'London',	1401),
(78,	3,	'Premium',	'Boston',	'Shanghai',	1903);

DROP TABLE IF EXISTS `hometitle`;
CREATE TABLE `hometitle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `maintitle` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `main_titile_descr` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `hometitle` (`id`, `maintitle`, `main_titile_descr`) VALUES
(1,	'Top Of The Top',	'A Quick Glance At This Weeks Best Offering ');

DROP TABLE IF EXISTS `login_user`;
CREATE TABLE `login_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `login_user` (`id`, `username`, `password`) VALUES
(1,	'admin',	'admin');

DROP TABLE IF EXISTS `mailsubscrib`;
CREATE TABLE `mailsubscrib` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mailid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateofsubs` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `mailsubscrib` (`id`, `mailid`, `dateofsubs`) VALUES
(52,	'pennys-dad@hotmail.com',	'Thursday February 19, 2015, 1:30 am'),
(53,	'zuqui56@yahoo.com',	'Wednesday March 18, 2015, 8:10 am'),
(54,	'daveryan2289@gmail.com',	'Friday March 20, 2015, 6:58 pm'),
(55,	'holly.pross@cruiseplanners.com',	'Friday March 27, 2015, 5:45 pm'),
(56,	'mterp@cruiseplanners.com',	'Wednesday April 1, 2015, 9:08 pm'),
(57,	'Barbara.Caruso@avoyatravel.com',	'Saturday April 11, 2015, 12:48 am'),
(58,	'donaldeoincarroll@gmail.com',	'Tuesday April 28, 2015, 11:43 pm'),
(59,	'siegel@nm.net',	'Tuesday May 12, 2015, 11:10 am'),
(60,	'pingclee@gmail.com',	'Thursday May 21, 2015, 3:24 am'),
(61,	'claudia.augustson@avoyatravel.com',	'Thursday June 11, 2015, 2:13 am'),
(62,	'rivieravac@cox.net',	'Thursday June 11, 2015, 2:15 am'),
(63,	'CODE7CRUISES@YAHOO.COM',	'Monday June 22, 2015, 8:37 pm');

DROP TABLE IF EXISTS `topoftop`;
CREATE TABLE `topoftop` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `subtitle` text COLLATE utf8_unicode_ci NOT NULL,
  `descriptioin` text COLLATE utf8_unicode_ci NOT NULL,
  `imagelink` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `topoftop` (`id`, `image`, `subtitle`, `descriptioin`, `imagelink`) VALUES
(1,	'AMEX-16755-1_300x250_300.jpg',	'&quot;Use Membership Rewards&reg; Points to Book Your Next Air Ticket&quot;',	'',	'http://www.travelrepnetwork.com'),
(2,	'cruise.jpg',	'Cruise Pricing ',	'book our airfare book your cruise\r\n',	''),
(3,	'qatar.jpg',	'Business Class',	'40% less for ambience and comfort.',	'');

DROP TABLE IF EXISTS `whatshottitle`;
CREATE TABLE `whatshottitle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `maintitle` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `main_titile_descr` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `whatshottitle` (`id`, `maintitle`, `main_titile_descr`) VALUES
(1,	'What\'s Hot',	'Our Airfare, Are Super Hot Today !');

-- 2015-06-23 08:48:22
