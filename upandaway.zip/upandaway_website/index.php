<?php
require_once("header.php");
?>
<div class="uaa_contents">

</div>
<?php
require_once("footer.php");
?>
		
	
	
	
	
