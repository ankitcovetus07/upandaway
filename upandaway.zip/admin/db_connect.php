<?php

$HOST= "localhost";     // The host you want to connect to.
$USER= "covetus_ayush";    // The database username. 
$PASSWORD= "Covetus@2014";    // The database password. 
$DATABASE="covetus_upandaway";    // The database name.

$connection = mysql_connect($HOST, $USER, $PASSWORD);
if (!$connection){
    die("Database Connection Failed" . mysql_error());
}
$select_db = mysql_select_db($DATABASE);
if (!$select_db){
    die("Database Selection Failed" . mysql_error());
	}
	
	
	 
?>
